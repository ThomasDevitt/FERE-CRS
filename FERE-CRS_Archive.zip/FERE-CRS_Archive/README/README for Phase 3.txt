
FERE-CRS Phase III: Supplementary Materials Project: Dynamic Cognitive Control and the Emergence of Artificial Fluid Reasoning Author: Thomas E. Devitt Date: July 27, 2025

This document provides an overview of the supplementary materials associated with the manuscript "FERE-CRS Phase III: Dynamic Cognitive Control and the Emergence of Artificial Fluid Reasoning."

These materials are provided to ensure full transparency, reproducibility, and to allow for a deeper inspection of the experimental methodology and results.

Table of Contents

Execution Script: The Python script used to run the entire experiment.

Generated Data Files: The data files produced during the experiment, including trained model weights and raw results.

Generated Figures: The publication-ready charts visualizing the key results, as referenced in the manuscript.

1. Execution Script
run_feres_experiment4.py

Description: This is the master Python script that executes the complete, three-stage FERE-CRS Phase III experiment. It is self-contained and includes all necessary logic and mock curricula to replicate the findings presented in the paper.

Functionality:

Stage 1 (Stance Training): Simulates the training of the "Cautious Logician" and "Exploratory Creative" cognitive stances, producing their respective CRS weight files.

Stage 2 (Classifier Training): Simulates the training and validation of the Meta-Cognitive Context Classifier (MCCC).

Stage 3 (Fluid Adaptation Test): Runs the main experiment, testing the Fluid Agent against the two control agents on the artifact analysis task.

Product Generation: Automatically creates all data files and figures listed below in the results/ and charts/ subdirectories.

2. Generated Data Files (located in the results/ directory)
weights_logician.json

Description: The output of the "Cautious Logician" training run in Stage 1. This file contains the final, optimized Cognitive Resonance Score (CRS) weights for the agent's convergent thinking stance.

weights_creative.json

Description: The output of the "Exploratory Creative" training run in Stage 1. This file contains the final, optimized CRS weights for the agent's divergent thinking stance.

mccc_model.json

Description: The output of the classifier training in Stage 2. This file contains the final, trained model parameters for the Meta-Cognitive Context Classifier (MCCC).

results4.csv

Description: This is the primary raw data log for the main experiment (Stage 3). It contains a step-by-step record of every action taken by all three agents (Fluid, Logician, Creative) across all 10 trials. For each step, it logs the active stance, MCCC classification (if applicable), CRS scores, and the final trial outcomes (quality and cost). This file is the source data for the H7 figures.

3. Generated Figures (located in the charts/ directory)
feres_phase_iii_h6_mccc_accuracy.png

Description: This chart corresponds to Figure 1 in the manuscript. It visualizes the final accuracy of the MCCC on the holdout test set, providing the evidence for Hypothesis 6 (H6).

feres_phase_iii_h7_performance_comparison.png

Description: This chart corresponds to Figure 2 in the manuscript. It presents the comparative performance of the Fluid, Logician, and Creative agents in terms of mean explanation quality and mean cognitive cost, providing the first part of the evidence for Hypothesis 7 (H7).

feres_phase_iii_h7_cognitive_stance_trace.png

Description: This chart corresponds to Figure 3 in the manuscript. It visualizes the dynamic, step-by-step switching of cognitive stances by the Fluid Agent during a representative trial. It provides the mechanistic explanation for the performance results and serves as the second part of the evidence for Hypothesis 7 (H7).

End of File