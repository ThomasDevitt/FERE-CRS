
FERE-CRS: A Cognitive Architecture for Emergent Fluid Reasoning and Autonomous Heuristic Discovery
This repository contains the complete source code, configuration files, and experimental data for the research program detailed in the manuscript, "FERE-CRS: A Cognitive Architecture for Emergent Fluid Reasoning and Autonomous Heuristic Discovery."

1. Project Overview
The Fluid Emergent Reasoning Engine (FERE-CRS) is a multi-phase research project aimed at developing a cognitive architecture capable of adaptive intelligence. Grounded in the Free Energy Principle and its process theory, Active Inference, the architecture is designed to move beyond the limitations of contemporary AI systems, which often struggle with out-of-distribution generalization and fluid reasoning.

This project introduces the Cognitive Resonance Score (CRS), a tractable heuristic that allows a Meta-Reasoning Agent (MRA) to orchestrate heterogeneous AI components (including Large Language Models) in a principled, AIF-consistent manner. The research is presented as a series of five interconnected studies, systematically building an agent with increasing levels of autonomy:

Study 1: Validates the foundational architecture's ability to perform high-quality, efficient reasoning.

Study 2: Demonstrates that the agent can learn a specialized "cognitive stance" via heuristic meta-learning.

Study 3: Implements dynamic cognitive control, allowing the agent to switch between learned stances.

Study 4: Creates a "cognitive engineer" agent that can generate novel cognitive stances for unseen problems.

Study 5: Achieves cognitive autonomy with a "cognitive scientist" agent that can discover and integrate new conceptual heuristics by reasoning about its own failures.

This repository provides all the necessary materials to understand, replicate, and build upon this work.

2. Repository Structure
The project is organized into the following directories:

FERE-CRS/
├── manuscript/
│   └── fere-crs-manuscript.pdf
│
├── code/
│   ├── run_feres_experiment1.py
│   ├── run_feres_experiment2.py
│   ├── run_feres_experiment3.py
│   ├── run_feres_experiment4.py
│   └── run_feres_experiment5.py
│
├── config/
│   ├── prompts_p1.json
│   ├── artifact_cases.json
│   ├── historical_facts.txt
│   ├── problem_classification_curriculum.json
│   ├── stance_generation_curriculum.json
│   ├── deceptive_cooperation_curriculum.json
│   └── ... (other configuration files)
│
├── results/
│   ├── phase1_results.csv
│   ├── phase2_weights_log_sudoku.csv
│   └── ... (output data, logs, and figures)
│
├── README.md
├── LICENSE
└── requirements.txt

manuscript/: Contains the final PDF version of the research paper.

code/: Contains the five primary Python scripts, each corresponding to a study in the manuscript.

config/: Contains all the necessary configuration files, including LLM prompts, task curricula, and agent parameters. These files act as the "mind" of the agent for each experiment.

results/: The default output directory where scripts will save CSV logs, data files, and generated figures. This folder may be empty initially.

README.md: This file.

LICENSE: The project's open-source license (e.g., MIT License).

requirements.txt: A list of the required Python libraries to run the experiments.

3. Setup and Dependencies
Prerequisites
Python 3.8 or newer.

An API key for a Large Language Model provider (e.g., Google AI Studio, OpenAI). The scripts assume this key is stored in an environment variable.

Installation
Clone the repository:

git clone https://github.com/YourUsername/FERE-CRS.git
cd FERE-CRS

Set up a virtual environment (recommended):

python -m venv venv
source venv/bin/activate  # On Windows, use `venv\Scripts\activate`

Install dependencies:
The requirements.txt file contains the necessary Python libraries.

# requirements.txt
pandas
numpy
matplotlib
scipy

Install them using pip:

pip install -r requirements.txt

Set your API Key:
The scripts require an API key to interact with an LLM. Set it as an environment variable in your terminal.

export GEMINI_API_KEY="YOUR_API_KEY_HERE"

4. Reproducing the Experiments
The following instructions detail how to run each of the five studies. Each script is self-contained and will reproduce the data and figures associated with its corresponding section in the manuscript.

Study 1: Foundational Architecture and Validation
Purpose: Compares the FERE-CRS agent against a RAG baseline on the artifact analysis task.

Script: code/run_feres_experiment1.py

Inputs: config/prompts_p1.json, config/artifact_cases.json, config/historical_facts.txt

Outputs: results/phase1_results.csv, results/H1_Quality.png, results/H2_Efficiency.png, results/H3_Behavior.png

To run:

python code/run_feres_experiment1.py

Expected Outcome: The script will simulate 500 trials, printing progress to the console. Upon completion, it will save the raw trial data to phase1_results.csv and generate the three figures corresponding to Hypotheses H1, H2, and H3 in the results/ directory.

Study 2: Learning a Cognitive Stance
Purpose: Demonstrates heuristic meta-learning by training agents on specialized curricula (Sudoku and AUT).

Script: code/run_feres_experiment2.py

Inputs: config/prompts_p2.json (contains task logic)

Outputs: results/phase2_weights_log_sudoku.csv, results/phase2_weights_log_aut.csv, results/phase2_weights_log_mixed.csv, results/H4_Specialization.png, results/H5_Adaptation.png

To run:

python code/run_feres_experiment2.py

Expected Outcome: The script will run three separate training loops (SUDOKU_ONLY, AUT_ONLY, MIXED), each for 200 epochs. It will save the weight evolution data for each run to a corresponding CSV file and generate the figures for H4 and H5.

Study 3: Dynamic Cognitive Control
Purpose: Tests the "Fluid Agent" with the MCCC against specialist controls.

Script: code/run_feres_experiment3.py

Inputs: config/prompts_p3.json, config/problem_classification_curriculum.json, config/artifact_cases.json

Outputs: results/phase3_mccc_accuracy.txt, results/phase3_fluid_agent_results.csv, results/H6_MCCC_Accuracy.png, results/H7_Performance.png, results/H7_Stance_Trace.png

To run:

python code/run_feres_experiment3.py

Expected Outcome: The script will first train and validate the MCCC, then run the comparison between the Fluid Agent and the two controls. It will save the results and generate the figures for H6 and H7.

Study 4: Generative Meta-Cognition
Purpose: Tests the "Generative Agent" with the SGN on a novel social-ethical dilemma.

Script: code/run_feres_experiment4.py

Inputs: config/prompts_p4.json, config/stance_generation_curriculum.json, config/social_dilemma_cases.json

Outputs: results/phase4_sgn_correlation.txt, results/phase4_generative_agent_results.csv, results/H8_SGN_Accuracy.png, results/H9_Performance.png

To run:

python code/run_feres_experiment4.py

Expected Outcome: The script will train the SGN, evaluate its correlation score, and then run the generative agent against the Phase 3 control agent. It will save the results and generate the figures for H8 and H9.

Study 5: Autonomous Heuristic Discovery
Purpose: Demonstrates the full Heuristic Discovery Loop with the "cognitive scientist" agent.

Script: code/run_feres_experiment5.py

Inputs: config/prompts_p5.json, config/deceptive_cooperation_curriculum.json, config/functional_primitives.json

Outputs: results/phase5_baseline_results.csv, results/phase5_augmented_results.csv, results/heuristic_discovery_log.txt, results/H12_Performance_Comparison.png

To run:

python code/run_feres_experiment5.py

Expected Outcome: The script will run the baseline agent (Stage 1), execute the Heuristic Discovery Loop (Stage 2), and then run the newly augmented agent (Stage 3). It will save the performance data for both stages, a detailed log of the discovery process, and the final H12 comparison figure.

5. Citation
If you use this work, please cite the manuscript and the archived software/data.

Manuscript:

Devitt, T. E. (2025). FERE-CRS: A Cognitive Architecture for Emergent Fluid Reasoning and Autonomous Heuristic Discovery.

Software & Data Archive:

Devitt, T. E. (2025). Software and Data for FERE-CRS: A Cognitive Architecture for Emergent Fluid Reasoning and Autonomous Heuristic Discovery (Version 1.0.0) [Software]. Zenodo. [Placeholder for Zenodo DOI]