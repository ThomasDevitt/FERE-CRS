======================================================================
README for Supplementary Material
FERE-CRS: A Validated Cognitive Architecture for Emergent, Fluid Reasoning via Active Inference
Version 1.0 - July 21, 2025
Thomas E. Devitt
======================================================================

### 1. OVERVIEW

This archive contains the complete set of files necessary to understand, replicate, and verify the results of the 500-trial experiment described in the main manuscript. The experiment was conducted using a "cognitive choreographer" methodology, where a Python script (the MRA) orchestrates a Large Language Model (Gemini 1.5 Pro) to perform a complex, inferential reasoning task. The files are organized into two categories: Choreographer's Assets (the human-readable configuration files that define the experiment's logic) and Experimental Data (the raw output from the 500-trial run).


### 2. CONTENTS OF THIS ARCHIVE

**Choreographer's Assets:**

* `run_feres_experiment2.py`: The main Python script that contains the logic for both the FERE-CRS agent and the RAG baseline, and which runs the experiment and the final analysis.
* `historical_facts.txt`: The Ontological Knowledge Base (OKB) for the experiment. This plain text file contains the ground-truth facts and causal rules of the synthetic archaeology domain.
* `artifact_cases.json`: The five base "case files" for the artifact analysis task. Each case provides the heterogeneous evidence package given to the agents.
* `prompts.json`: The complete library of prompt templates used by the MRA to direct the LLM to perform its various cognitive functions (e.g., hypothesizing, evaluating, synthesizing).
* `config.json`: The strategic configuration for the MRA, including the CRS weights and the costs associated with each cognitive action.

**Experimental Data:**

* `results2.csv`: The primary experimental data. This is a detailed, step-by-step log of every action taken by both agents across all 500 trials, including the calculated CRS component scores for the FERE-CRS agent.
* `experiment_log.txt`: The complete, unabridged terminal output from the full 500-trial experimental run. This serves as the raw "lab notebook" for the experiment.
* `H1_quality_chart.png`: The bar chart visualizing the mean explanation quality scores (H1).
* `H2_cost_chart.png`: The bar chart visualizing the mean computational cost (H2).
* `H3_behavior_plot2.png`: The line plot visualizing the FERE-CRS agent's adaptive behavior (H3).


### 3. SETUP AND REQUIREMENTS

To replicate this experiment, you will need the following:

1.  **Python 3.9+**
2.  **Required Python Libraries:** These can be installed via pip from your terminal:
    ```
    pip install pandas google-generativeai matplotlib seaborn
    ```
3.  **A Google API Key:** You must obtain an API key for the Gemini model from Google AI Studio and set it as an environment variable. The script will look for an environment variable named `GOOGLE_API_KEY`.


### 4. RUNNING THE EXPERIMENT

1.  Place all files from this archive into a single folder.
2.  Ensure your `GOOGLE_API_KEY` environment variable is set correctly.
3.  Open a terminal or command prompt, navigate to the folder containing the files, and execute the script:
    ```
    python run_feres_experiment2.py
    ```

**Note on Execution Time and Cost:** The script is configured to run the full 500-trial experiment. This is a computationally intensive process that will take several hours to complete and will make thousands of API calls. Ensure you have enabled billing on your Google Cloud project and have set appropriate budget alerts before running.

**Validation Run:** To run a short (5-trial) validation test that completes in a few minutes, you can modify the final lines of the `run_feres_experiment2.py` script to `run_experiment(num_trials=5)`.


### 5. EXPECTED OUTPUT

Upon completion, the script will:
1.  Print the summary tables for H1, H2, and H3 to the terminal.
2.  Overwrite the `results2.csv` file with the new data from the run.
3.  Generate/overwrite the three `.png` chart files in the same folder.

Thank you for your interest in this research.
