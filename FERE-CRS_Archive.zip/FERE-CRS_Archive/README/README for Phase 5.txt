
# Supplementary Materials for:
# FERE-CRS Phase V: Heuristic Discovery and the Emergence of Cognitive Autonomy

**Author:** Thomas E. Devitt, Independent Researcher
**Date:** August 1, 2025

---

## 1. Overview

This repository contains the full set of supplementary materials for the manuscript, "FERE-CRS Phase V: Heuristic Discovery and the Emergence of Cognitive Autonomy." The files provided here allow for the complete replication of the computational experiment described in the paper, which demonstrates an AI agent's capacity to autonomously discover and integrate a new cognitive heuristic.

The experiment is designed as a three-stage, pre-test/post-test simulation that tracks the performance of a FERE-CRS agent before and after it undergoes a process of cognitive self-expansion.

---

## 2. Contents of Supplementary Materials

This package includes one Python script and four JSON configuration files.

### **Code:**

* **`run_feres_experiment6.py`**
    * **Purpose:** The main Python script that executes the entire three-stage experiment. It simulates the FERE-CRS agent, its environment, and the Heuristic Discovery Loop (MCAD, AIM, HSE modules).
    * **Dependencies:** `numpy`, `matplotlib`

### **Configuration Files (Inputs):**

* **`config_p5.json`**
    * **Purpose:** Sets the global parameters for the experiment, including the number of trials per stage and the thresholds for the agent's meta-cognitive modules.

* **`prompts_p5.json`**
    * **Purpose:** Contains the specific, high-level prompt used to simulate the Abductive Inference Module's (AIM) query to its core LLM. This ensures the transparency of the conceptual abduction step.

* **`deceptive_cooperation_curriculum.json`**
    * **Purpose:** Defines the problem space for the experiment. It contains a series of "Deceptive Cooperation" task descriptions, including the ground-truth state of the partner agent (cooperative or deceptive), which is necessary for evaluating the agent's performance.

* **`functional_primitives.json`**
    * **Purpose:** Provides the library of basic functions for the Heuristic Synthesis Engine (HSE). The HSE uses these primitives to construct the new 'Trustworthiness' heuristic function.

---

## 3. How to Run the Experiment

To replicate the results presented in the manuscript, please follow these steps:

1.  **Prerequisites:** Ensure you have Python 3 installed along with the `numpy` and `matplotlib` libraries. You can install them using pip:
    ```bash
    pip install numpy matplotlib
    ```

2.  **Setup:** Place all five files (`run_feres_experiment6.py` and the four `.json` files) into a single directory.

3.  **Execution:** Navigate to that directory in your terminal or command prompt and run the script:
    ```bash
    python run_feres_experiment6.py
    ```

4.  **Outputs:** The script will run for a few moments and will automatically generate the following output files in the same directory:
    * `results_p5.csv`: A detailed log of all 200 trials.
    * `heuristic_discovery_log.txt`: A human-readable narrative of the discovery process.
    * `H12_Performance_Comparison.png`: The bar chart visualizing the pre- vs. post-discovery performance.
    * `final_report_p5.md`: A summary markdown file of the key findings.

---

## 4. Contact

For any questions regarding this research or the supplementary materials, please contact Thomas E. Devitt.
