
Supplementary Materials for "FERE-CRS Phase II: Heuristic Meta-Learning in an Active Inference Agent"
July 26, 2025

This document describes the contents of the supplementary materials accompanying the manuscript. These files provide the full source code, data, and results for the experiment, ensuring full transparency and reproducibility.

--- PYTHON SCRIPTS (.py) ---

1.  run_feres_experiment3.py
    -   Purpose: This is the main experimental script. It loads the curriculum data, initializes the FERE-CRS agent, and executes the heuristic meta-learning loop. The `CURRICULUM_MODE` variable can be changed to run the 'SUDOKU_ONLY', 'AUT_ONLY', or 'MIXED' experimental conditions.

2.  plot_sudoku.py
    -   Purpose: Reads `results_sudoku.csv` and generates the line chart visualizing the agent's specialization on the SUDOKU_ONLY curriculum (Figure 1).

3.  plot_aut.py
    -   Purpose: Reads `results_aut.csv` and generates the line chart visualizing the agent's specialization on the AUT_ONLY curriculum (Figure 2).

4.  plot_mixed.py
    -   Purpose: Reads `results_mixed.csv` and generates the line chart visualizing the agent's adaptation on the MIXED curriculum (Figure 3).

--- CURRICULUM DATA FILES (.txt, .json) ---

5.  sudoku_rules.txt
    -   Purpose: A plain text file containing the ground-truth rules for the Sudoku task.

6.  sudoku_puzzles.json
    -   Purpose: A JSON file containing the unsolved Sudoku grids and their solutions.

7.  creative_tasks.json
    -   Purpose: A JSON file containing the list of objects for the Alternative Uses Test.

--- EXPERIMENTAL RESULTS (.csv) ---

8.  results_sudoku.csv
    -   Purpose: The raw data log from the 'SUDOKU_ONLY' experimental run.

9.  results_aut.csv
    -   Purpose: The raw data log from the 'AUT_ONLY' experimental run.

10. results_mixed.csv
    -   Purpose: The raw data log from the 'MIXED' experimental run.

--- GENERATED FIGURES (.png) ---

11. sudoku_specialization_chart.png
    -   Purpose: The chart visualizing the results from `results_sudoku.csv` (Figure 1).

12. aut_specialization_chart.png
    -   Purpose: The chart visualizing the results from `results_aut.csv` (Figure 2).

13. mixed_adaptation_chart.png
    -   Purpose: The chart visualizing the results from `results_mixed.csv` (Figure 3).